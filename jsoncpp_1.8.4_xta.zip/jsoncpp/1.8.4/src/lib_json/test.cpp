/*
 * test.cpp
 *
 *  Created on: 2018��11��13��
 *      Author: Hopen
 */

#include <cstdio>
#include <cstdlib>
#include <cstring>

#include <iostream>
#include <sstream>
#include <string>

#include <stdexcept>

#include <json/json.h>

#if 1
int main(int argc, char* argv[])
{
	try
	{
		char buf[] =
				"{"
					"\"class\":\"200302\","
					"\"student\":"
					"["
						"{"
							"\"id\":\"200302001\","
							"\"name\":\"����\","
							"\"age\":23"
						"},"
						"{"
							"\"id\":\"200302002\","
							"\"name\":\"����\","
							"\"age\":22"
						"}"
					"]"
				"}"
				;

//		char buf[] = "{ \"property\" : \"value\", \"key\" : \"val1\", \"key\" : \"val2\" }";
		Json::CharReaderBuilder crb;
		crb.strictMode(&crb.settings_);
		Json::CharReader* reader(crb.newCharReader());
		Json::Value root;
		std::string err;
		if(!reader->parse(buf, buf+strlen(buf), &root, &err))
		{
			std::stringstream ss;
			ss <<__FILE__ <<", " <<__LINE__ <<", " <<"Json::CharReader::parse()::failed, '" <<err;
			throw std::runtime_error(ss.str());
		}

//		Json::Value::Members mb = root.getMemberNames();
//		for(Json::Value::Members::iterator it = mb.begin(); it != mb.end(); it++)
//		{
//			std::cout <<*it <<std::endl;
//		}

		Json::Value student = root["student"];
//		std::cout <<student.toStyledString();
		printf("%s, %d, ----------------------\n", __FILE__, __LINE__);
		for(u_int i = 2; i < 10; i++)
		{
			student[i]["id"] = "200302003";
			student[i]["name"] = student[i]["id"];
			student[i]["age"] = (int)i;
		}
		std::cout <<student.toStyledString();


		printf("%s, %d, ----------------------\n", __FILE__, __LINE__);
		student[1].removeMember("id");
		student[2].removeMember("age");
		student[3].removeMember("name");
		std::cout <<student.toStyledString();

		printf("%s, %d, ----------------------\n", __FILE__, __LINE__);
		student.removeIndex(4, NULL);
		std::cout <<student.toStyledString();

//		printf("%s, %d, ----------------------\n", __FILE__, __LINE__);
//		for(u_int i = 0; i < student.size(); i++)
//		{
//			std::cout <<"{"                                                   <<std::endl;
//			std::cout <<"\"id\":\""   <<student[i]["id"  ].asString() <<"\""  <<std::endl;
//			std::cout <<"\"name\":\"" <<student[i]["name"].asString() <<"\""  <<std::endl;
//			std::cout <<"\"age\":"    <<student[i]["age" ].asInt()            <<std::endl;
//			std::cout <<"}"                                                   <<std::endl;
//		}
	}
	catch(std::exception& e)
	{
		std::cout <<e.what();
	}

	return 0;
}
#endif

